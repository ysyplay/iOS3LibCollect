//
//  UITableViewCell+YsyTemplateLayoutCell.m
//  Demo
//
//  Created by Runa on 2017/9/29.
//  Copyright © 2017年 forkingdog. All rights reserved.
//

#import "UITableViewCell+YsyTemplateLayoutCell.h"

@implementation UITableViewCell (YsyTemplateLayoutCell)
-(CGFloat)calculateHeight:(CGSize)size{
    NSLog(@"请在cell中实现-(CGFloat)calculateHeight:(CGSize)size");
    return 0;
}
@end
