//
//  UITableViewCell+YsyTemplateLayoutCell.h
//  Demo
//
//  Created by Runa on 2017/9/29.
//  Copyright © 2017年 forkingdog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (YsyTemplateLayoutCell)
-(CGFloat)calculateHeight:(CGSize)size;
@end
